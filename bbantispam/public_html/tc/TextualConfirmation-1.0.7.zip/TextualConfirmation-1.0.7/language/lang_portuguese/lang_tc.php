<?php
/***************************************************************************
 *                          lang_tc.php [Portugu�s]
 *                            -------------------
 *   begin                : Wednesday, May 02, 2007
 *   copyright            : (C) 2007 J�lio Sousa
 *   email                : jspt@clix.pt
 *
 *   $Id: lang_tc.php 1915 2007-03-12 07:28:40Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Resposta incorrecta � pergunta de Confirma��o Textual';
$lang['tc_explain']            = 'Responda � pergunta de Confirma��o Textual para comprovar que n�o se trata de um spambot.';
$lang['tc_mail_subject']       = 'Tentativa de Registo SPAM no f�rum';
$lang['Textual_Confirmation']  = 'Confirma��o Textual';
$lang['tc_admin_dup_question'] = "<p>Pergunta duplicada: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>N�o se reconhece o grupo de pergunta/resposta(s): '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Pergunta guardada: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Pergunta(s) antiga(s) eliminada(s):%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Foi actualizada a base de dados.</p>\n";
$lang['tc_admin_explanation']      = "<p>Separa os blocos de pergunta-resposta por una linha em branco. Em cada bloco, a primeira linha ser� a pergunta e as restantes ser�o as hip�teses de resposta correcta. A pergunta deve ser HTML v�lido. As respostas n�o distinguen maiusculas e min�sculas.</p>\n";

?>