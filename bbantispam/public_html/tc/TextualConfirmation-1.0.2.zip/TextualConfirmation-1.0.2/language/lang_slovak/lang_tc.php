<?php
/***************************************************************************
 *                          lang_tc.php [Slovakian]
 *                            -------------------
 *   begin                : Thursday, Oct 19, 2006
 *   copyright            : (C) 2006 bbAntiSpam
 *   email                : support@bbantispam.com
 *
 *   $Id: lang_tc.php 1198 2006-10-29 04:31:35Z olpa $
 *
 *   Slovak translation: Dino <dino@slowakia.sk>
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Nespr�vna odpove� na ot�zku Textov�ho Overenia.';
$lang['tc_explain']            = 'Odpovedzte na ot�zku Textov�ho Overenia aby ste dok�zal, �e nie ste spamovac� automat.';
$lang['tc_mail_subject']       = 'phpBB spam registr�cia';
$lang['Textual_Confirmation']  = 'Textov� Overenie';
$lang['tc_admin_dup_question'] = "<p>Duplicitn� ot�zka: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>Nedok�em sp�rova� ot�zku s odpove�ou: '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Ot�zka ulo�en�: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Star�(�) ot�zka(y) zmazan�:%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Datab�za aktualizovan�.</p>\n";
$lang['tc_admin_explanation']      = "<p>Oddel bloky ot�zok pr�zdnym riadkom. V ka�dom bloku mus� by� prv� riadok ot�zka a �al�ie riadky jednotliv� spr�vne odpovede. Ot�zka mus� sp��a� po�iadavky spr�vneho syntaxu HTML. Odpovede nie s� citliv� na druh p�sma (ve�k�/mal�).</p>\n";

?>