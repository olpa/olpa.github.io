<?php
/*
Plugin Name: Oleg Parashchenko's AdSense
Plugin URI: http://uucode.com/wp-adsense
Version: 0.1
Description: Allows to insert Google AdSense at the top of the "read the rest of this entry" page.
Author: Oleg Parashchenko <olpa uucode com>
Author URI: http://uucode.com/
*/

/*
Copyright:  Oleg Parashchenko
License:    GNU General Public License

Usage:

1) Put the file to "wp-content/plugins".
2) Activate the plugin (Admin Panel -> Plugins -> Activate).
3) In your template directory, edit the file "single.php". Find

<div class="entrytext">
  <?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>

and change to:

<div class="entrytext">
  <?php include (TEMPLATEPATH . '/adsense_single.php'); ?>
  <?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>

4) Create the file "adsense_single" in the template directory. Content:

<?php
olpa_adsense_set(<<<EOT
<script type="text/javascript"><!--
... your AdSense code here ...
</script>
EOT
);
?>

*/

$olpa_adsense_code = <<<EOT
<script type="text/javascript"><!--
google_ad_client = "pub-8908956343180748";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
google_ad_channel ="0446693607";
google_color_border = "336699";
google_color_bg = "FFFFFF";
google_color_link = "0000FF";
google_color_url = "008000";
google_color_text = "000000";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
EOT;

function olpa_adsense_filter($text) {
  global $olpa_adsense_code;
  // "a" for older versions, "span" for newer versions
  $text = ereg_replace('(<(a|span) id="more-[0-9]+"><\/(a|span)>)', "\\1$olpa_adsense_code", $text);
  return $text;
}

function olpa_adsense_set($text = '') {
  global $olpa_adsense_code;
  if (! empty ($text)) {
    $olpa_adsense_code = $text;
  }
  add_filter('the_content', 'olpa_adsense_filter');
}

?>
