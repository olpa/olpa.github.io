<?php
/***************************************************************************
 *                          lang_tc.php [Catalan]
 *                            -------------------
 *   begin                : Saturday, Mar 10, 2007
 *   copyright            : (C) 2007 Giledhel Narya
 *   email                : narya@elcea.es
 *
 *   $Id$
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Resposta no v�lida a la pregunta de Confirmaci� Textual';
$lang['tc_explain']            = 'Respon la pregunta de Confirmaci� Textual per a que poguem comprovar que no ets un spambot.';
$lang['tc_mail_subject']       = 'Intent de registre spam al forum';
$lang['Textual_Confirmation']  = 'Confirmaci� Textual';
$lang['tc_admin_dup_question'] = "<p>Pregunta duplicada: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>No es reconeix el grup pregunta-resposta: '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Pregunta guardada: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Pregunta(es) antiga(es) eliminada(es):%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>S'ha actualitzat la base de dades.</p>\n";
$lang['tc_admin_explanation']      = "<p>Separa els blocs de pregunta-resposta amb una l�nea en blanc. A cada bloc, la primera l�nea n'�s la pregunta, y la resta son les respostes correctes. La preguntada ha de ser formulada en HTML v�lid. Les respostes no fan distinci� entre maj�scules i min�scules.</p>\n";

?>