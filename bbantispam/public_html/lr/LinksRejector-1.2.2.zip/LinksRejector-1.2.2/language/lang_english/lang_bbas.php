<?php
/***************************************************************************
 *                          lang_bbas.php [English]
 *                            -------------------
 *   begin                : Thursday, Apr 6, 2006
 *   copyright            : (C) 2006 bbAntiSpam
 *   email                : support@bbantispam.com
 *
 *   $Id: lang_bbas.php 1239 2006-11-02 06:40:57Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['bbas_guest_contacts_forbidden'] = 'Contact information can be posted only by registered users.';
$lang['bbas_mail_subject'] = 'phpBB spam';

?>
