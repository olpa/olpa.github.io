<?php
/***************************************************************************
 *                          lang_bbas.php [French]
 *                            -------------------
 *   begin                : Friday, Oct 15, 2008
 *   copyright            : (C) 2008 Peter van Het Hurktoilet
 *   email                : <hurktoilet gmail com>
 *
 *   $Id: lang_bbas.php 2612 2008-10-14 07:04:07Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['bbas_guest_contacts_forbidden'] = 'Seulement les visiteurs enregistr�s peuvent y mettre des liens';
$lang['bbas_mail_subject'] = 'phpBB spam';

?>
