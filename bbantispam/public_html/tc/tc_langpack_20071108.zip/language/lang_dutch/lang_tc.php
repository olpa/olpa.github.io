<?php
/***************************************************************************
 *                          lang_tc.php [Dutch]
 *                            -------------------
 *   begin                : Thursday, May 10, 2007
 *   copyright            : (C) 2007 bertjeuh
 *   email                : PM bertjeuh in the phpBB forum
 *
 *   $Id: lang_tc.php 1198 2006-10-29 04:31:35Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Verkeerd antwoord op de tekstuele-confirmatie-vraag.';
$lang['tc_explain']            = 'Antwoord op de tekstuele-confirmatie-vraag om te bewijzen dat u geen spambot bent.';
$lang['tc_mail_subject']       = 'phpBB spam registratie';
$lang['Textual_Confirmation']  = 'Tekstuele confirmatie';
$lang['tc_admin_dup_question'] = "<p>Duplicate vraag: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>Kan de vraag/antwoord-paren niet verwerken: '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Vraag bewaard: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Oude vragen verwijderd:%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Database is upgedate.</p>\n";
$lang['tc_admin_explanation']      = "<p>Verdeel de vraag-blokken door een lege lijn. In elke blok is de eerste lijn de vraag en de overige lijnen zijn de juiste antwoorden. De vraag-string moet geldige HTML zijn. De vragen zijn hoofdlettergevoelig.</p>\n";

?>
