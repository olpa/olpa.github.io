Language pack for Textual Confirmation
======================================

05/17/07

Bulgarian      diabolic.bg <PM diabolic.bg in the phpBB forum>
Catalan        Giledhel Narya <narya elcea es>
Dutch          bertjeuh <PM bertjeuh in the phpBB forum>
French         tran quoc minh <tranquocminh gmail com>
German Formal  Adrian Suter <php adriansuter ch>
Italian        Gigi <ostiaxboz gmail com>
Korean         phpbbKOREA <acharabia hotmail com>
Portuguese     J�lio Sousa <jspt clix pt>
Russian        Oleg Parashchenko <olpa uucode com>
Slovakian      Dino <dino slowakia sk>
Spanish        Giledhel Narya <narya elcea es>
Traditional Chinese Taiwan - big5  Robert Lee <robmlee gmail com>
Ukrainian      Volodymyr Kurylenko <vkurylenko yahoo co uk>

-- 
bbAntiSpam Textual Confirmation
http://bbantispam.com/tc/
