<?php
/***************************************************************************
 *                          lang_tc.php [Italian]
 *                            -------------------
 *   begin                : Saturday, Mar 10, 2007
 *   copyright            : (C) 2007 Gigi
 *   email                : ostiaxboz@gmail.com
 *
 *   $Id: lang_tc.php 1916 2007-03-12 07:29:21Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Risposta sbagliata nella domanda di Conferma Testuale.';
$lang['tc_explain']            = 'Rispondi alla domanda di Conferma Testuale per verificare di essere umano -ANTISPAM- .';
$lang['tc_mail_subject']       = 'phpBB registrazione spam';
$lang['Textual_Confirmation']  = 'Conferma Testuale';
$lang['tc_admin_dup_question'] = "<p>Domanda doppia: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>Impossibile processare la coppia domanda/risposta: '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Domanda salvata: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Vecchia domanda cancellata:%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Database aggiornato.</p>\n";
$lang['tc_admin_explanation']      = "<p>Separa i blocchi di domande con delle linee vuote. In ogni blocco, la prima riga e' una domanda, e le righe restanti sono le risposte corrette. La stringa per la domanda puo' contenere codice HTML valido. Le domande sono case-insensitive.</p>\n";

?>