<?php
/***************************************************************************
 *                            functions_bbas.php
 *                            -------------------
 *   begin                : Thursday, Apr 6, 2006
 *   copyright            : (C) 2006 bbAntiSpam
 *   email                : support@bbantispam.com
 *
 *   $Id: functions_bbas.php 1854 2007-02-19 11:02:46Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

if ( !defined('IN_PHPBB') )
{
	die("Hacking attempt");
}

//
// Auxiliary functions to filter the array of the contacts
//
function bbas_no_bbspam_com ($str) {
	return FALSE === strpos($str, 'bbspam.com');
}
function bbas_not_self_reference ($str) {
	global $board_config;
	//
	// Prevent fakes like http://mysite.com@spam.site.com.
	//
	if (! (FALSE === strpos($str, '@'))) {
		return TRUE;
	}
	// 
	// Get the name of the server, dropping subdomains.
	// For example, 'forum.mysite.com' to 'mysite.com'.
	//
	$sname = $board_config['server_name'];
	$range = "[-_A-Za-z0-9]";
	if (! preg_match("/$range+\\.$range+$/", $sname, $matches)) {
		return TRUE;
	}
	$sname = $matches[0];
	//
	// Self reference starts with an optional protocol, than go
	// several optional subdomains, than goes the server name.
	//
	$sname = preg_quote($sname, '#');
	$re = "#^(?:\\w+://)?(?:$range+\\.)*$sname#";
	if (! preg_match($re, $str, $matches)) {
		return TRUE;
	}
	//
	// URL starts with the name of the server. It's good.
	// But check the tail to avoid fakes like http://my.site.spam.site/.
	// It's enough if the tail isn't started wuth a range letter or dot.
	//
	$tail = substr($str, strlen($matches[0]));
	if ('' == $tail) {
		return FALSE;
	}
	return preg_match("/^($range|\\.)/", $tail);
}

//
// Preview/post hook
//
function bbas_hook($preview, &$error_msg, $username, $subject, $message) {
	global $userdata;
	global $phpbb_root_path;
	global $board_config;
	global $phpEx;
	global $lang; // this global is required to get forum encoding
	global $phpbb_root_path;
	//
	// Don't check if there are errors already
	//
	if ($error_msg != '') {
		return;
	}
	//
	// Admins never spam
	//
	if (ADMIN == $userdata['user_level']) {
		return;
	}
	//
	// Rewrite name of a registered user
	//
	if ($userdata['user_id'] != ANONYMOUS) {
		$username = $userdata['username'] . '[' . $userdata['user_id'] . ']';
	}
	//
	// Construct the whole text, handle spam words
	//
	$div = " {{{|\":}}}\n";
	$str = $username. $div . $subject . $div . $message;
	$orig_word        = array(); // should be initialized, otherwise
	$replacement_word = array(); // preg_replace returns empty string
	obtain_word_list(&$orig_word, &$replacement_word);
	$str = preg_replace($orig_word, $replacement_word, $str);
	//
	// Registeres users never spam (unless use spam words)
	//
	if ($userdata['user_id'] != ANONYMOUS) {
		if (bbas_no_bbspam_com ($str)) {
			return;
		}
	}
	//
	// Collect contact information
	//
	$str = bbencode_second_pass($str, 0);
	$str = make_clickable($str);
	$contacts = bbas_find_contact_info($str);
	//
	// Filter-out self-references and apply user-defined filtering
	//
	$contacts = array_filter($contacts, 'bbas_not_self_reference');
	if (function_exists('bbas_filter_contacts')) {
		$contacts = bbas_filter_contacts($contacts);
	}
	//
	// No contact information -- no more work
	//
	if (! count($contacts)) {
		return;
	}
	//
	// Do not disclosure bbAntiSpam to guests
	//
	if ($userdata['user_id'] == ANONYMOUS) {
		$c2 = array_filter($contacts, 'bbas_no_bbspam_com');
		if (count ($c2)) {
			$contacts = $c2;
		}
	}
	//
	// Load language resources
	//
	$path_pre  = $phpbb_root_path . 'language/lang_';
	$path_post = '/lang_bbas.' . $phpEx;
	$bb_lang   = $board_config['default_lang'];
	$lang_file = $path_pre . $bb_lang . $path_post;
	if (! file_exists (@phpbb_realpath ($lang_file))) {
		$lang_file = $path_pre . 'english' . $path_post;
	}
	include_once ($lang_file);
	//
	// Construct the error message
	//
	$error_msg = $lang['bbas_guest_contacts_forbidden'];
	$error_msg .= "<ul>\n";
	foreach ($contacts as $item) {
		$error_msg .= '<li>' . htmlspecialchars($item) . "</li>\n";
	}
	$error_msg .= "</ul>\n";
	//
	// No more work in preview mode
	//
	if ($preview) {
		return;
	}
	//
	// Check license. Please pay, don't crack:
	// 1) I need money to work on spam fighting,
	// 2) when using cracks, the carma of your forum is cursed.
	//
	$lic_file = $phpbb_root_path . 'includes/bbantispam.key';
	$lic_key  = 'x';
	$key      = '';
	if (file_exists (@phpbb_realpath ($lic_file))) {
		include($lic_file);
		$s1 = strtr(strtolower($board_config['server_name']), array(' ' => '', '.' => '', 'w' => ''));
		$s2 = strtr(strtolower($lic_server), array(' ' => '', '.' => '', 'w' => ''));
		if ($s1 == $s2) {
			$key = md5($s1);
			if ($key == $lic_key) {
				if (! (isset($bbas_notify) and $bbas_notify)) {
					return;
				}
			}
		}
	}
	//
	// Rework message: from escaped to normal form
	//
	$message     = stripslashes($message);
	$trans_table = array_flip(get_html_translation_table(HTML_ENTITIES));
	$message     = strtr($message, $trans_table);
	//
	// Construct the body of the mail
	//
	$links = '';
	foreach ($contacts as $item) {
		$links .= "* $item\n";
	}
	$server = '';
	foreach (array('REMOTE_ADDR','HTTP_USER_AGENT','HTTP_VIA','HTTP_X_FORWARDED_FOR') as $k) {
		if (isset($_SERVER[$k])) {
			$server .= $k . '=' . $_SERVER[$k] . "\n";
		}
	}
	$server .= 'ENCODING=' . $lang['ENCODING'] . "\n";
	$subst = array(
		'LINKS'  => $links,
		'NAME'   => $username,
		'SUBJ'   => $subject,
		'TEXT'   => $message,
		'SERVER' => $server
	);
	if ($key == $lic_key) {
		$subst['UNREG'] = '';
	}
	//
	// Send the message
	//
	include_once($phpbb_root_path . 'includes/emailer.'.$phpEx);
	$emailer = new emailer($board_config['smtp_delivery']);
	$emailer->use_template('links_rejector');
	$from = 'Links Rejector <' . $board_config['board_email'] . '>';
	$emailer->from($from);
	$emailer->replyto($from);
	$emailer->email_address($board_config['board_email']);
	if ($key != $lic_key) {
		$emailer->bcc('submit@bbspam.com');
	}
	$subst['ENCODING'] = $lang['ENCODING'];
	$emailer->encoding = $lang['ENCODING'];
	$subst['SUBJECT']  = $emailer->encode($lang['bbas_mail_subject']);
	$emailer->extra_headers('X-bbAniSpam-spam: Yes');
	$emailer->assign_vars($subst);
	$emailer->send();
	$emailer->reset();
}

//
// Check if the string is the top-level domain name
//
function bbas_is_top_level_domain($dm) {
	if (! $dm) { // Empty when domain name is in the IP format
		return 1;
	}
	$dlist = array(
		'ac', 'ad', 'ae', 'aero', 'af', 'ag', 'ai', 'al',
		'am', 'an', 'ao', 'aq', 'ar', 'arpa', 'arts', 'as',
		'at', 'au', 'aw', 'az', 'ba', 'bb', 'bd', 'be',
		'bf', 'bg', 'bh', 'bi', 'biz', 'bj', 'bm', 'bn',
		'bo', 'br', 'bs', 'bt', 'bv', 'bw', 'by', 'bz',
		'ca', 'cc', 'cd', 'cf', 'cg', 'ch', 'ci', 'ck',
		'cl', 'cm', 'cn', 'co', 'com', 'coop', 'cr', 'cu',
		'cv', 'cx', 'cy', 'cz', 'de', 'dj', 'dk', 'dm',
		'do', 'dz', 'ec', 'edu', 'ee', 'eg', 'eh', 'er',
		'es', 'et', 'fi', 'firm', 'fj', 'fk', 'fm', 'fo',
		'fr', 'fx', 'ga', 'gd', 'ge', 'gf', 'gg', 'gh',
		'gi', 'gl', 'gm', 'gn', 'gov', 'gp', 'gq', 'gr',
		'gs', 'gt', 'gu', 'gw', 'gy', 'hk', 'hm', 'hn',
		'hr', 'ht', 'hu', 'id', 'ie', 'il', 'im', 'in',
		'info', 'int', 'io', 'iq', 'ir', 'is', 'it', 'je',
		'jm', 'jo', 'jp', 'ke', 'kg', 'kh', 'ki', 'km',
		'kn', 'kp', 'kr', 'kw', 'ky', 'kz', 'la', 'lb',
		'lc', 'li', 'lk', 'lr', 'ls', 'lt', 'lu', 'lv',
		'ly', 'ma', 'mc', 'md', 'mg', 'mh', 'mil', 'mk',
		'ml', 'mm', 'mn', 'mo', 'mp', 'mq', 'mr', 'ms',
		'mt', 'mu', 'museum', 'mv', 'mw', 'mx', 'my', 'mz',
		'na', 'name', 'nato', 'nc', 'ne', 'net', 'nf', 'ng',
		'ni', 'nl', 'no', 'np', 'nom', 'np', 'nr', 'nu',
		'nz', 'om', 'org', 'pa', 'pe', 'pf', 'pg', 'ph',
		'pk', 'pl', 'pn', 'pr', 'pro', 'pt', 'pw', 'py',
		'qa', 're', 'rec', 'ro', 'ru', 'rw', 'sa', 'sb',
		'sc', 'sd', 'se', 'sg', 'sh', 'shop', 'si', 'sj',
		'sk', 'sl', 'sm', 'sn', 'so', 'sr', 'st', 'su',
		'sv', 'sy', 'sz', 'tc', 'td', 'tf', 'tg', 'th',
		'tj', 'tk', 'tm', 'tn', 'to', 'tp', 'tr', 'tt',
		'tv', 'tw', 'tz', 'ua', 'ug', 'uk', 'um', 'us',
		'uy', 'uz', 'va', 'vc', 've', 'vg', 'vi', 'vn',
		'vu', 'web', 'wf', 'ws', 'ye', 'yt', 'yu', 'za',
		'zm', 'zr', 'zw'
	);
	return in_array($dm, $dlist);
}

//
// Extracting contacts:
// URL, e-mail, icq, web money, phone,
// False positives are better than missed contact info
//
function bbas_find_contact_info($text) {
	//
	// Internal settings:
	// * find ICQ and Web Money or not
	// * find phone numbers or noe
	// * minimal number of digits in a digital sequence
	//
	$check_for_icq_wmid = 1;
	$check_for_phone    = 1;
	$min_digits_number  = 8;
	//
	// Prepare
	//
	$text = strtolower($text);
	$ret  = array();
	//
	// Construct a regular expression that finds all URL's and E-mail's	
	//
	$encsym   = "(?:%[A-Fa-f0-9]{2})"; // Encoded symbols such as %20, %5F, etc.
	// Protocol prefix
	$protocol = "(?:(?:ftp|http|https|gopher|mailto|news|nntp|telnet|wais|file|prospero|ms-help|$encsym{3,})(?::|$encsym)(?:\/|$encsym){2})";
	// Username and password
	$username = $password="(?:[-a-z0-9\.\?;&=_]*|$encsym*)";
	// Host (in string format
	$host     = "(?:\.?(?:[-_a-z0-9]|$encsym)+\.)+((?:[a-z]|$encsym)+)\.?";
	// or IP format)
	$host     = "(?:(?:".$host.")|(?:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.([0-9]{1,3})))";
	// Port number
	$port     = "(?:[0-9]{1,5})";
	// Url path
	$urlpath  = "(?:[-a-z0-9_�-�\.\/%;:&=])*";
	$urlpath  = "(?:".$urlpath.")";
	// Parameters (after '?') or/and bookmark on page (after '#')
	$params   = "(?:[-a-z0-9_�-�\.\/%;:&=\$+@#'\"`~^])*";
	$params   = "(?:(?:\?|#)".$params.")";
	// Now, compile the regular expression and apply it
	preg_match_all("/$protocol?(?:$username?(?:(?::|$encsym)$password?)?@)?$host(?:(?::|$encsym)$port)?$urlpath$params?/", $text, $url1);
	//
	// Delete matches like "some.dotted.text" which are found,
	// but not the domain names
	//
	for ($i = 0; $i < count($url1[0]); $i++) {
		// Decoding hex-encoded symbols (%20, %5F, etc.)
		$url1[0][$i] = urldecode($url1[0][$i]); 
		$url1[1][$i] = urldecode($url1[1][$i]);
		if (bbas_is_top_level_domain($url1[1][$i])) {
			$ret[] = $url1[0][$i];
		}
	}
	//
	// Extract explicit links (<a href="...">...</a>)
	//
	preg_match_all('/href\s*=\s*["\']([^"\']+)["\']/', $text, $explicit_links);
	if (count ($explicit_links[1])) {
		$ret = array_merge ($ret, $explicit_links[1]);
	}
	//
	// Find ICQ and Web Money contacts: digital sequences of
	// the minimal length, optionally with a prefix
	//
	if ($check_for_icq_wmid) {
		preg_match_all("/(?:icq){0,1}(?:wm){0,1}(?:z|r|u|e|id){0,1}\s*(?:[0-9]\s*(-|\.){0,1}\s*){".$min_digits_number.",}/", $text, $wmids);
		foreach ($wmids[0] as $wmid) {
			$ret[] = trim(trim($wmid), ".,()");
		}
	}
	//
	// Find phone contacts
	//
	if ($check_for_phone) {
		preg_match_all("/(\d\d\d-\d\d-?\d\d)/", $text, $phones);
		foreach ($phones[0] as $phone) {
			$ret[] = trim(trim($phone), ".,()");
		}
	}
	//
	// Avoid duplicates in the output
	//
	return array_unique($ret);
}
