<?php
/***************************************************************************
 *                          lang_tc.php [Lithuanian]
 *                            -------------------
 *   begin                : Tuesday, Nov 6, 2007
 *   copyright            : (C) 2007 Elvis
 *   email                : no thanks
 *
 *   $Id: lang_tc.php 1198 2007-11-06 22:35:15Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Klaidingas atsakymas � Tekstinio Patvirtinimo klausim�.';
$lang['tc_explain']            = '�rodyk, kad nesi �iuk�linimo robotas, atsakydamas � Tekstinio Patvirtinimo klausim�.';
$lang['tc_mail_subject']       = 'phpBB forumo �iuk�lintoj� registracija';
$lang['Textual_Confirmation']  = 'Tekstinis Patvirtinimas';
$lang['tc_admin_dup_question'] = "<p>Klausimas kartojasi: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>Negaliu apdoroti klausimo/atsakym� poros: '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Klausimas i�saugotas: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Senas(-i) klausimas(-ai) i�trinti:%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Duombaz� atnaujinta.</p>\n";
$lang['tc_admin_explanation']      = "<p>Atskiri klausim� blokai turi b�ti atskirti tu��ia eilute. Kiekviename bloke pirma eilut� yra klausimas, likusios eilut�s yra teisingi atsakymai. Klausimo eilut� turi b�ti validus HTML. Atsakymuose did�iosios ir ma�osios raid�s neturi reik�m�s.</p>\n";

?>
