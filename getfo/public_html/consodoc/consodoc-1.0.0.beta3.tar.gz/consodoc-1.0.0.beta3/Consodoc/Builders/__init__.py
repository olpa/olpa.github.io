# Consodoc Publishing Server
# Copyright (c) Oleg Parashchenko, <olpa consodoc com>
