<?php
/***************************************************************************
 *                        lang_tc.php [German Formal]
 *                          -----------------------
 *   begin                : Thursday, Oct 19, 2006
 *   copyright            : (C) 2006 Adrian Suter
 *   email                : php@adriansuter.ch
 *
 *   $Id: lang_tc.php 1198 2006-12-06 00:00:00Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Falsche Antwort zur Sicherheitsfrage.';
$lang['tc_explain']            = 'Zur Best�tigung dass Sie kein Spambot sind, beantworten Sie bitte die Sicherheitsfrage.';
$lang['tc_mail_subject']       = 'phpBB Spam Registration';
$lang['Textual_Confirmation']  = 'Sicherheitsfrage';
$lang['tc_admin_dup_question'] = "<p>Doppelte Frage: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>Kann das Frage/Antworten Paar nicht parsen: '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Frage gespeichert: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Alte Frage(n) gel�scht:%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Die Datenbank wurde aktualisiert.</p>\n";
$lang['tc_admin_explanation']      = "<p>Trennen Sie einzelne Fragebl�cke mittels leerer Zeile. Die erste Zeile eines Frageblockes definiert die Frage, alle folgenden Zeilen die korrekten Antworten (pro Zeile eine Antwort). Die Frage muss g�ltiger HTML Code sein. Die Gross-/Kleinschreibung der Antworten wird nicht ber�cksichtigt.</p>\n";

?>
