<?php
/***************************************************************************
 *                          lang_tc.php [Spanish]
 *                            -------------------
 *   begin                : Saturday, Mar 10, 2007
 *   copyright            : (C) 2007 Giledhel Narya
 *   email                : narya@elcea.es
 *
 *   $Id: lang_tc.php 1915 2007-03-12 07:28:40Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Respuesta no v�lida a la pregunta de Confirmaci�n Textual';
$lang['tc_explain']            = 'Responde la pregunta de Confirmaci�n Textual para que podamos comprobar que no eres un spambot.';
$lang['tc_mail_subject']       = 'Intento de registro spam en foro';
$lang['Textual_Confirmation']  = 'Confirmaci�n Textual';
$lang['tc_admin_dup_question'] = "<p>Pregunta duplicada: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>No se reconoce el grupo de pregunta/respuesta(s): '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Pregunta guardada: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Pregunta(s) antigua(s) eliminada(s):%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Se ha actualizado la base de datos.</p>\n";
$lang['tc_admin_explanation']      = "<p>Separa los bloques de pregunta-respuesta por una l�nea en blanco. En cada bloque, la primera l�nea es la pregunta, y el resto son las respuestas correctas. La pregunta debe ser HTML v�lido. Las respuestas no distinguen may�sculas y min�sculas.</p>\n";

?>