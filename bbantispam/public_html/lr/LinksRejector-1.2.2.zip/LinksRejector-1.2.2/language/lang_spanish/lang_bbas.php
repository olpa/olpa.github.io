<?php
/***************************************************************************
 *                          lang_bbas.php [English]
 *                            -------------------
 *   begin                : Friday, Sep 7, 2007
 *   copyright            : (C) 2006 Gabriel Godoy
 *   email                : <webmaster forofueguino com>
 *
 *   $Id: lang_bbas.php 1239 2006-11-02 06:40:57Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['bbas_guest_contacts_forbidden'] = 'Informaci�n de contacto es posible solo para usuarios registrados.';
$lang['bbas_mail_subject'] = 'phpBB spam';

?>
