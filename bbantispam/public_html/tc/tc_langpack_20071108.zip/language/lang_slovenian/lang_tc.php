<?php
/***************************************************************************
 *                          lang_tc.php [Slovenian]
 *                            -------------------
 *   begin                : Thursday, Nov 7, 2007
 *   copyright            : (C) 2007 Vili Jan
 *   email                : info reber.si
 *
 *   translated by        : www.reber.si
 *
 *   $Id: lang_tc.php 1198 2006-10-29 04:31:35Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Napa�en odgovor na vpra�anje.';
$lang['tc_explain']            = 'Odgovori na vpra�anje, da doka�e�, da nisi spam-bot. �e ne pozna� odgovora, pritisni tipko F5, oziroma osve�i/refresh.';
$lang['tc_mail_subject']       = 'neuspe�na phpBB registracija';
$lang['Textual_Confirmation']  = 'Tekstovna potrditev';
$lang['tc_admin_dup_question'] = "<p>Dvojno vpra�anje: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>Ne morem raz�leniti para vpra�anje/odgovor: '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Vpra�anje shranjeno: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Stara vpra�anja so izbrisana:%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Baza je posodobljena.</p>\n";
$lang['tc_admin_explanation']      = "<p>Posamezne bloke z vpra�anjem in odgovori lo�i s prazno vrstico. V vsakem bloku je prva vrstica vpra�anje, ostale vrstice pa pravilni odgovori. Vpra�anje mora biti veljaven HTML. Odgovori niso ob�utljivi na velike-male �rke.</p>\n";

?>
