<?php
/***************************************************************************
 *                          lang_tc.php [Romanian no diacritics]
 *                            -------------------
 *   begin                : Thursday, Oct 23, 2007
 *   copyright            : (C) 2007 Voicu Potrovita
 *   email                : voicu.potrovita eldior ro
 *
 *   $Id: lang_tc.php 1198 2006-10-29 04:31:35Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Raspuns incorect la intrebarea Confirmarii Textuale.';
$lang['tc_explain']            = 'Raspundeti la intrebarea Confirmarii Textuale pentru a arata ca nu sunteti spambot.';
$lang['tc_mail_subject']       = 'phpBB spam registration';
$lang['Textual_Confirmation']  = 'Confirmare Textuala';
$lang['tc_admin_dup_question'] = "<p>Intrebare duplicat: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>Nu pot parcurge intrebarea/perechile de raspunsuri: '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Intrebare salvata: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Intrebarea/Intrebarile vechi sterse:%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Baza de date updatata.</p>\n";
$lang['tc_admin_explanation']      = "<p>Separati blocurile de intrebari printr-o linie goala. Prima linie a fiecarui bloc este intrebarea, iar restul liniilor sunt raspunsurile corecte. Intrebarea trebuie sa fie un sir de caractere HTML valid. Raspunsurile sunt case-insensitive.</p>\n";

?>
