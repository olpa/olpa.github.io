<?php
// $Id: bbantispam.php 2257 2007-08-04 05:48:28Z olpa $
// Advanced Textual Confirmation, <<VERSION:1.0.3>>
// (c) 2007 bbAntiSpam, info@ http://bbantispam.com/atc/

//
// Load config
//
$bbas_config = dirname(__FILE__) . '/bbas_config.php';
include $bbas_config;

//
// Create alias variables used in encrypted version
//
foreach (array('oonf_nyjnlf_pbasvezrq', 'dhrfgvbaf', 'ynat', 'yvprafr_xrl', 'pbasvezngvba_cntr') as $bbas_orig) {
  $bbas_orig = str_rot13($bbas_orig);
  $bbas_new  = 'bbas_V' . substr(md5($bbas_orig), 0, 8);
  $GLOBALS[$bbas_new] = &$$bbas_orig;
}
global $questions, $lang, $license_key, $confirmation_page;
global $bbas_always_confirmed, $bbas_atc_q, $bbas_atc_a;

//
// If protection isn't required, or the user is verified,
// skip to the main script.
//
$bbas_verified = bbas_is_confirmed();
if (! $bbas_verified) {
  $bbas_verified = bbas_try_confirm();
}
if ($bbas_verified) {
  //
  // Cleanup, then return to the main script
  //
  if (! defined('BBAS_TEST_MODE')) {
    bbas_cleanup();
  }
  return;
}
// execution continues at (***)

//
// Delete local global variables
//
function bbas_cleanup() {
  foreach ($GLOBALS as $k=>$v) {
    if (($k == 'questions') or ($k == 'lang') or ($k == 'license_key') or ($k == 'confirmation_page') or ($k == 'bbas_always_confirmed') or ($k == 'bbas_atc_q') or ($k == 'bbas_atc_a') or (substr($k, 0, 5) == 'bbas_')) {
      unset($GLOBALS[$k]);
    }
  }
}

//
// Protection is required if:
// * user submits a form, and
// * human marker is absent or wrong.
//
function bbas_is_confirmed() {
  //
  // In test mode, confirm immediately.
  //
  if (defined('BBAS_TEST_MODE')) {
    global $bbas_always_confirmed;
    if (isset($bbas_always_confirmed) and $bbas_always_confirmed) {
      return 1;
    }
  }
  //
  // Nothing to protect if not POST
  //
  if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    return 1;
  }
  //
  // Don't protect if license is wrong
  //
  if (! bbas_checksum_valid()) {
    return 1;
  }
  //
  // Marker should present and be correct
  //
  if (isset($_COOKIE['bbas_pass_code'])) {
    $pass = bbas_get_pass_code();
    if ($_COOKIE['bbas_pass_code'] == $pass) {
      return 1;
    }
  }
  return 0;
}

//
// Form variables
//
function bbas_setup_form_vars() {
  global $bbas_atc_q, $bbas_atc_a;
  $bbas_atc_q = sprintf('bbas%u', crc32(bbas_generate_id('bbas_atc_q')));
  $bbas_atc_a = sprintf('bbas%u', crc32(bbas_generate_id('bbas_atc_a')));
}

//
// If the confirmation form was submitted, check the answer
//
function bbas_try_confirm($set_cookie = 1) {
  global $questions, $bbas_atc_q, $bbas_atc_a;
  bbas_setup_form_vars();
  //
  // Get user answer
  //
  if (! (isset($_POST[$bbas_atc_q]) and isset($_POST[$bbas_atc_a]))) {
    return 0;
  }
  $question_id = $_POST[$bbas_atc_q];
  $answer      = $_POST[$bbas_atc_a];
  $answer      = strtolower(trim($answer));
  //
  // Find the question/answers pair in config.
  //
  foreach ($questions as $q=>$a) {
    if (bbas_generate_id($q) == $question_id) {
      $answers = $a;
      break;
    }
  }
  if (! isset($answers)) {
    return 0;
  }
  //
  // Check if the answer is correct
  //
  $answer_is_correct = 0;
  foreach ($answers as $a) {
    $a = strtolower(trim($a));
    if ($a == $answer) {
      $answer_is_correct = 1;
      break;
    }
  }
  if (! $answer_is_correct) {
    return 0;
  }
  //
  // Setup pass code
  //
  if ($set_cookie) {
    $pass = bbas_get_pass_code();
    setcookie('bbas_pass_code', $pass, time()+60*60*24*300, '/');
  }
  return 1;
}

//
// Generate ID by string. ID is client-dependent.
//
function bbas_generate_id($s) {
  $salt = bbas_get_pass_code();
  return md5($salt . $s);
}

//
// Generate a pass code:
// Hash of questions, server name, admin email, client IP(s), browser
//
function bbas_get_pass_code() {
  global $questions;
  ob_start();
  foreach (array('SERVER_NAME', 'SERVER_ADMIN', 'HTTP_USER_AGENT') as $var) {
    if (isset($_SERVER[$var])) {
      print($_SERVER[$var] . "\n");
    }
  }
  $s_ip = bbas_get_client_ip_string();
  print $s_ip . "\n";
  print_r($questions);
  $s = ob_get_contents();
  ob_end_clean();
  return md5($s);
}

//
// Identify client by IP and proxy. Regard those users who
// use balancing proxies and dynamic IPs: use network address,
// not exact client IP.
//
function bbas_get_client_ip_string() {
  //
  // Generate regexp
  //
  $ip_block = '[0-9]{1,3}';
  $ip_re    = "/($ip_block\\.$ip_block\\.$ip_block)\\.$ip_block/";
  //
  // Match regexp against data
  //
  $a_ip = array();
  foreach (array('REMOTE_ADDR','HTTP_VIA','HTTP_X_FORWARDED_FOR') as $var) {
    if (isset($_SERVER[$var])) {
      if (preg_match_all($ip_re, $_SERVER[$var], $more)) {
        $a_ip = array_merge ($a_ip, $more[1]);
      }
    }
  }
  //
  // Convert to string
  //
  $s_ip = implode(',', $a_ip);
  return $s_ip;
}

//
// Check if the site owner has a correct license
//
function bbas_checksum_valid() {
  return 1;
  global $confirmation_page, $license_key;
  $s = strtr(strtolower($_SERVER['SERVER_NAME']), array(' ' => '', '.' => '', 'w' => ''));
  if (md5($s) == $license_key) {
    return 1;
  }
  $cp = str_replace("\r", '', $confirmation_page);
  $cp = str_replace("\n", '', $cp);
  if (md5($cp) == '9a608a82520ef40dc60dee528989db92') {
    return 1;
  }
  return 0;
}


// (***) --------------------------------------------------

//
// Select a question
//
$question    = array_rand($questions);
$question_id = bbas_generate_id($question);

//
// Collect the data submitted
//
$data = $_POST;
$data[$bbas_atc_q] = $question_id;
unset($data[$bbas_atc_a]);
function bbas_data_to_hidden($data) {
  $hidden = '';
  foreach ($data as $k => $v) {
    if (! is_array($v)) {
      if (get_magic_quotes_gpc()) {
        $v = stripslashes($v);
      }
      $hidden .= sprintf('<input type="hidden" name="%s" value="%s">%s',
        $k, htmlspecialchars($v), "\n");
    } else {
      //
      // Serialize the array variable
      // Support the case: $a[] = '1'; $a['la'] = '2'; $a[] = '3'
      //
      $prefix = is_int($k) && ($k == 0) ? '': $k;
      foreach ($v as $k2=>$v2) {
        $name = is_int($k2) ? $prefix . '[]' : $prefix . '[' . $k2 . ']';
        $data2 = array($name => $v2);
        $hidden .= bbas_data_to_hidden($data2);
      }
    }
  }
  return $hidden;
}
$hidden = bbas_data_to_hidden($data);

//
// Generate HTML
//
$subst = array(
  '{ACTION}'        => $_SERVER['REQUEST_URI'],
  '{QUESTION}'      => $question,
  '{FIELD_ANSWER}'  => $bbas_atc_a,
  '{HIDDEN_FIELDS}' => $hidden,
  '{RANDOM}'        => rand(0,9)
);
foreach ($lang as $k=>$v) {
  $subst['{'.$k.'}'] = $v;
}
foreach ($subst as $k=>$v) {
  $confirmation_page = str_replace($k, $v, $confirmation_page);
}

//
// Print the page and exit
//
$charset = $lang['CHARSET'];
header("Content-type: text/html; charset=$charset");
print($confirmation_page);
exit;

?>
