<?php
/***************************************************************************
 *                          lang_tc.php [Romanian]
 *                            -------------------
 *   begin                : Thursday, Oct 23, 2007
 *   copyright            : (C) 2007 Voicu Potrovita
 *   email                : voicu.potrovita eldior ro
 *
 *   $Id: lang_tc.php 1198 2006-10-29 04:31:35Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'R�spuns incorect la �ntrebarea Confirm�rii Textuale.';
$lang['tc_explain']            = 'R�spunde�i la �ntrebarea Confirm�rii Textuale pentru a ar�ta c� nu sunte�i spambot.';
$lang['tc_mail_subject']       = 'phpBB spam registration';
$lang['Textual_Confirmation']  = 'Confirmare Textual�';
$lang['tc_admin_dup_question'] = "<p>�ntrebare duplicat: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>Nu pot parcurge �ntrebarea/perechile de r�spunsuri: '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>�ntrebare salvat�: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>�ntrebarea/�ntreb�rile vechi �terse:%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Baza de date updatat�.</p>\n";
$lang['tc_admin_explanation']      = "<p>Separa�i blocurile de �ntreb�ri printr-o linie goal�. Prima linie a fiec�rui bloc este �ntrebarea, iar restul liniilor sunt r�spunsurile corecte. �ntrebarea trebuie s� fie un �ir de caractere HTML valid. R�spunsurile sunt case-insensitive.</p>\n";

?>
