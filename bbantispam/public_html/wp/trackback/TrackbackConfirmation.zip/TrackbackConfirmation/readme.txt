Trackback Confirmation plugin for WordPress
http://bbantispam.com/wp/trackback/

Finally, I've released yet another but unique anti-spam plugin for WordPress. The formal description:

<blockquote>Publishing of a trackback or a pingback is postponed till someone, usually a trackback author, approves it. Trackbacks which are not approved in 20 hours are automatically deleted. It stops spam from bots and allows trackbacks from the real humans.</blockquote>

A better description is probably a description by an use case:

* Alice has Trackback Confirmation installed.
* Bob has written a blog post with a link to Alice's blog post.
* Bob checks if a trackback appears in the Alice's blog.
* No, the trackback hasn't appeared. But Bob notices the link ``approve trackbacks''.
* He follows the links, finds his trackback and approves it.
* Now Alice's blog links to the Bob's post.

It's just a web 2.0 style of trackback moderation. Comments are approved not by the blog's author, but by the blog's visitors.

<!--more-->

If you like the idea, <a href="http://bbantispam.com/wp/trackback/TrackbackConfirmation.zip">download the plugin Trackback Confirmation</a>. How to install:

* Unpack the file ``<code>tbconf.php</code>'' and put it into the folder ``<code>wp-plugins</code>''.
* Activate the plugin (the admin area, the pane ``Plugins'').
* Create a page (the admin area, the pane ``Manage'', the subpane ``Pages''). This page will be used as a template page for Trackback Confirmation.
* Configure the plugin (the admin area, the pane ``Plugins'', the subpabe ``Trackback Confirmation'').
* Now you can assign the status ``private'' to the template page, if you want.

<h3>Warning</h3>

The code is unmaintained. I don't provide any support. If you have any questions, please ask them in the WordPress support forum.

Why?

My blogs are not popular, and are very rarely linked. Therefore, further improvement of the script isn't profitable. Meanwhile, I got a better idea how to fight the trackback spam (see ``<a href="http://uucode.com/blog/2008/01/15/decline-and-fall-of-the-trackbacks-rise-and-resurrection-of-the-trackbacks/">decline and fall of the trackbacks; rise and resurrection of the trackbacks</a>''). As result, I simply disabled trackbacks and deactivated the plugin. Obviously, I don't have any incentive to support it.

But the code is written and works well. I hope someone can take over the code and continue development. Here is the short TODO list:

* If there are no trackbacks: do not print an empty table, but say something.
* On the moderation page, add a link to the post from a comment.
* Make sure that HTML is escaped on the template page.
* Make sure that there are no SQL injections (shouldn't be possible, but it's better to audit).
* Notifications should be sent not using PHP function ``<code>mail</code>'', but using WordPress function ``<code>wp_notify_postmaster</code>''.
* Instead of using SQL to change the trackback status, the code should use something like ``<code>wp_set_comment_status(ID,'approve')</code>''.
* Add some design.
* Submit Trackback Confirmation to WordPress plugin repository.

-- 
Oleg Parashchenko olpa@ http://uucode.com/blog/
