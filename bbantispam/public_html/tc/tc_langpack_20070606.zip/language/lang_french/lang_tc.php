<?php
/***************************************************************************
 *                          lang_tc.php [French]
 *                            -------------------
 *   begin                : Thursday, Oct 19, 2006
 *   copyright            : (c) 2007 tran quoc minh
 *   email                : tranquocminh@gmail.com
 *
 *   $Id: lang_tc.php 1198 2006-10-29 04:31:35Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Mauvaise r�ponse � la question de Confirmation Textuelle (antispam).';
$lang['tc_explain']            = 'R�pondez � la question de Confirmation Textuelle (antispam) pour prouver que vous �tes un humain et non un robot spammeur.';
$lang['tc_mail_subject']       = 'Tentative de spam sur votre forum phpBB';
$lang['Textual_Confirmation']  = 'Confirmation textuelle';
$lang['tc_admin_dup_question'] = "<p>Question redondante: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>Impossible d'identifier les questions/r�ponses : '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Question enregistr�e: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Ancienne(s) question(s) effac�e(s):%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Base de donn�es mise � jour.</p>\n";
$lang['tc_admin_explanation']      = "<p>S�parez les blocs de questions/r�ponses par une ligne vide. Dans chaque bloc, la premi�re ligne est une question, les lignes suivantes sont les r�ponses correctes attendues. Le formatage de la question doit �tre compatible avec le HTML. Les majuscules / minuscules ne sont pas prises en compte dans les r�ponses.</p>\n";

?>
