<?php
/*
Plugin Name: Trackback Confirmation
Plugin URI: http://bbantispam.com/wp/trackback/
Description: Publishing of a trackback or a pingback is postponed till someone, usually a trackback author, approves it. Trackbacks which are not approved in 1 hour are automatically deleted. It stops spam from bots and allows trackbacks from the real humans.
Author: Oleg Parashchenko
Version: 1.0
Author URI: http://uucode.com/blog/
Credits: Alex Zhukoff <http://zhukoff.com/> wrote for me the initial version
*/ 

//////////////CONFIG//////////////
// delete after (3600 == 1h, 72000=20h)
$config_tnp['ttl'] = 72000;
// chop message
$config_tnp['chop'] = 350;
//////////////////////////////////


///////////////CSS////////////////
function tnp_css (){
    echo '
    <style type="text/css">
        .tnp_blck { border: 1px #555 dotted; padding: 10px; margin: 30px 5px 30px 0px; }
    </style>';}
//////////////////////////////////

function tnpOption($Name, $Value = false) {
	global $wpdb;
	$String = get_option('tnp_config');
	$String = explode('|', $String);
	if ($Value == false) {
		if ($Name == 'replace') return stripslashes($String[0]);
		if ($Name == 'title') return stripslashes($String[1]);
		if ($Name == 'link') return stripslashes($String[2]);
		if ($Name == 'success') return stripslashes($String[3]);
	} else {
		if ($Name == 'replace') $String[0] = $Value;
		if ($Name == 'title') $String[1] = $Value;
		if ($Name == 'link') $String[2] = $Value;
		if ($Name == 'success') $String[3] = $Value;
		$Update = $String[0].'|'.$String[1].'|'.$String[2].'|'.$String[3];
		update_option('tnp_config', $Update);
	}
}


function tnpSetup() {
	if (function_exists('add_submenu_page')) add_submenu_page('plugins.php', __('Trackback Confirmation plugin'), __('Trackback Confirmation'), 1, __FILE__, 'tnpSetupView');
	add_option('tnp_config', __('appr_tnp|Approve trackbacks||Approved!|', 'Settings for Trackback Confirmation plugin'));
}

function tnpSetupView() {
	if ($_POST['submit']) {
		check_admin_referer();
		tnpOption('title', $_POST['linktitle']);
		tnpOption('link', $_POST['formurl']);
		tnpOption('success', $_POST['successmessage']);
?>
<div id="message" class="updated fade"><p><strong><?php _e('Options saved.') ?></strong></p></div>
<?php
	}
	$pages = get_pages();
	foreach ($pages as $page) {
		if ($page->ID != tnpOption('link')) {
			$Select .= "<option value='$page->ID'>$page->post_title</option>";
		} else {
			$Select .= "<option value='$page->ID' selected=\"selected\">$page->post_title</option>";
		}
	}
?>
<div class="wrap">
 <h2><?php _e('Trackback Confirmation'); ?></h2>
 <p><?php printf(__('Settings for <a href="%1$s">Trackback Confirmation plugin</a>.'), 'http://bbantispam.com/wp-trackback/'); ?></p>
 <form action="" method="post">
  <fieldset class="options"> 
   <legend><?php _e('Link Replacement'); ?></legend> 
   <table class="optiontable"> 
    <tr valign="top"> 
     <th scope="row"><?php _e('Link title:'); ?></th> 
     <td><input name="linktitle" type="text" id="linktitle" value="<?php echo tnpOption('title'); ?>" size="40" /><br />
         <?php _e('This will be the title of the link to Trackback Confirmation plugin.'); ?></td> 
    </tr> 
   </table>
  </fieldset>
  <fieldset class="options">
   <legend><?php _e('Plugin Page'); ?></legend>
   <table class="optiontable"> 
    <tr valign="top"> 
     <th scope="row"><?php _e('Template page:'); ?></th>
     <td><select name="formurl" id="formurl" style="width:300px;"><?php echo $Select; ?></select><br />
         <?php _e('This is the page that will display plugin.'); ?></td> 
    </tr>
	<tr valign="top"> 
     <th scope="row"><?php _e('Success message:'); ?></th>
     <td><input name="successmessage" type="text" id="successmessage" style="width: 95%" value="<?php echo tnpOption('success'); ?>" size="45" /><br />
         <?php _e('This is the message the user will see after approving.'); ?></td> 
    </tr>
   </table>
  </fieldset> 
  <p class="submit"><input type="submit" name="submit" value="Update Options &raquo;" /></p>
 </form>
</div>
<?php
}

function tnpShow($Content) {
global $wpdb, $config_tnp, $css_blck;
	if (is_page(tnpOption('link'))) {
        tnpLink('all');
		if ($_POST['submit'] && is_numeric($_POST['contactprocess'])) {
		    $Headers = 'MIME-Version: 1.0'."\n".
	        'From: Trackback Confirmation mail'."\n".
			'Content-Type: text/plain; charset="'.get_settings('blog_charset').'"'."\n";
            $Message = $_POST['contactname'].' writes:'."\n\n".
            'Comment ID: '.$_POST['contactprocess']. " has been approved. \n";
            $wpdb->query("UPDATE $wpdb->comments SET comment_approved = '1' where comment_ID = '{$_POST['contactprocess']}'");
            @mail(get_option('admin_email'), 'Approved', $Message, $Headers);
			return '<p>'.tnpOption('success').'</p>';
        } else {
            if (@$_GET['pt'] && is_numeric(@$_GET['pt'])){
                $tmpSQLq = " AND comment_post_ID = '{$_GET['pt']}'";
            } else { $tmpSQLq = ""; }
            $Form = '';
            $comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_approved = '0' AND comment_type != '' $tmpSQLq");
            if (@$comments) {
                foreach($comments as $comment) {
                    if ((strtotime('now') - strtotime($comment->comment_date)) > $config_tnp['ttl']){
                        $wpdb->query("DELETE FROM $wpdb->comments WHERE comment_ID = $comment->comment_ID");
                    } else {
                    $Form .= '<div class="tnp_blck"><b>';
                    $Form .= '<a href="' . $comment->comment_author_url . '">' . $comment->comment_author .'</a></b> [ '.mysql2date(get_option("date_format") . " @ " . get_option("time_format"), $comment->comment_date). ' ]';
                    $Form .= '<p class="postmetadata alt" style="text-align: left;">'.substr($comment->comment_content, 0, $config_tnp['chop']).'...'."\n";
                    $Form .= '<br /></p><form action="" method="post"><fieldset>'."\n";
                    $Form .= '<br /><input type="hidden" name="contactprocess" value="'.$comment->comment_ID.'" /><input name="submit" type="submit" id="submit" tabindex="5" value="Approve" />'."\n". 
                    '</fieldset></form></div>'."\n";
                    }
                }
            }
        return $Content.$Form;
		}
	} else {
		return $Content;
	}
}

function tnpLink ($tnpAll){
    global $wpdb, $post;
    $tmp_pid = $post->ID;
    if (!@$tmp_pid){$tmp_pid = "a";}
    $Link = get_settings('home').'/?page_id='.tnpOption('link').'&amp;pt='.($tnpAll == 'all' ? "a" : $tmp_pid);
    echo '<a href="'.$Link.'" title="'.tnpOption('title').'">'.($tnpAll == 'all' ? "Show All &gt;&gt;" : tnpOption('title')).'</a>';
}

add_action('wp_head', 'tnp_css');
add_filter('the_content', 'tnpShow', 7);
add_action('comment_form', 'tnpLink', 1);
add_action('admin_menu', 'tnpSetup');
?>
