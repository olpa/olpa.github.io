Language pack for Advanced Textual Confirmation
http://bbantispam.com/atc/
