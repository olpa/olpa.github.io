<?php
/***************************************************************************
 *                          lang_tc.php [Norwegian]
 *                            -------------------
 *   begin                : Thursday, May 29, 2007
 *   copyright            : (c) 2007 goldclone.com
 *   email                : No thanx
 *   made by              : goldclone.com
 *
 *   $Id: something $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Feil svar p&aring; Textual Confirmation sp&oslash;rsm&aring;let.';
$lang['tc_explain']            = 'Svar p&aring; Textual Confirmation sp&oslash;rsm&aring;let for &aring; bevise at du ikke er en spambot.';
$lang['tc_mail_subject']       = 'phpBB spam registration';
$lang['Textual_Confirmation']  = 'Textual Confirmation';
$lang['tc_admin_dup_question'] = "<p>Kopi av sp&oslash;rsm&aring;let: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>Kan ikke valdere sp&oslash;rsm&aring;let/svaret: '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Sp&oslash;rsm&aring;let lagret: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Gamle sp&oslash;rsm&aring;l slettet:%s</p>\n";
$lang['tc_admin_database_updated'] = "<p>Databasen er oppdatert.</p>\n";
$lang['tc_admin_explanation']      = "<p>Separer sp&oslash;rsm&aring;let med en tom linje. I hvert avsnitt er den f&oslash;rste linjen sp&oslash;rsm&aring;let, og resten korrete svar. Sp&oslash;rsm&aring;let m&aring; v�re gjyldig HTML. Svaret er sensitivt p� sm&aring; og store bokstaver.</p>\n";

?>
