<?php
// Advanced Textual Confirmation settings
// (c) 2007 bbAntiSpam, info@ http://bbantispam.com/atc/

//
// The text before "=>" is a question. The array after "=>" is
// the valid answers. You should not use the special symbols ("<",
// ">", "&", "\", "$", '"' and "'") unless you know HTML and PHP.
//
$questions = array(
  'Are you human?' => array ('yes', 'ja'),
  'Say "Hello"'    => array ('hello', 'hi', 'hallo')
);

//
// The text messages. Again, don't use the special symbols.
//
$lang = array (
  'CHARSET'  => 'iso-8859-1',
  'TITLE'    => 'Advanced Textual Confirmation',
  'EXPLAIN'  => 'Answer the question to prove you are not a spam bot, but a human.',
  'SUBMIT'   => 'Submit Answer',
  'FOOTNOTE' => 'This site is protected with <a href="http://bbantispam.com/atc/" target="_blank">Advanced Textual Confirmation</a> from <a href="http://bbantispam.com/" target="_blank">bbAntiSpam</a>.'
);

//
// The layout of the confirmation page can be changed only
// if you have a license key. Otherwise Advanced Textual
// Confirmation stops working.
//
$license_key = '00000000';
$confirmation_page = <<<EOT
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset={CHARSET}">
<title>{TITLE}</title>
<style type="text/css">
body {
  background:   #eff7f3;
  color:        #000000;
}
a:link     {  color: #006699;  }
a:visited  {  color: #006666;  }
a:hover    {  color: #0066FF;  }
a:active   {  color: #0066FF;  }
* {
  font-family:  tahoma, verdana, sans-serif;
}
div.footnote {
  font-size:    66%;
  border-top:   2px #008080 solid;
}
span.question {
  background:   #ffff00;
}
</style>
</head>
<body>
<table border="0" width="100%" height="100%">
<tr>
<td align="center" valign="middle">
<form action="{ACTION}" method="POST">
{EXPLAIN}<br /><br />
<span class="question">{QUESTION}</span><br /><br />
<input type="text" style="width: 200px" name="{FIELD_ANSWER}" size="25" value="" /><br /><br />
<input type="submit" value="{SUBMIT}"/>
{HIDDEN_FIELDS}</form>
</td>
</tr>
<tr valign="bottom" height="40">
<td><div class="footnote">{FOOTNOTE}
<img src="/{RANDOM}_Advanced_Textual_Confirmation_Is_Shareware_Please_Buy_At_bbAntiSpam_dot_com.png" alt="" title="" width="1" height="1" border="0">
</div></td>
</tr>
</table>
</body>
</html>
EOT;

?>
