<?php
/***************************************************************************
 *                          lang_bbas.php [Dutch]
 *                            -------------------
 *   begin                : Friday, Oct 15, 2008
 *   copyright            : (C) 2008 Peter van Het Hurktoilet
 *   email                : <hurktoilet gmail com>
 *
 *   $Id: lang_bbas.php 2611 2008-10-14 07:00:50Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['bbas_guest_contacts_forbidden'] = 'Contact-informatie en links kunnen alleen geplaatst worden door geregistreerde gebruikers.';
$lang['bbas_mail_subject'] = 'phpBB spam';

?>
